
<?php $__env->startSection('content'); ?>
<h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gazi-global-network-ltd\laravel\resources\views/backend/pages/dashboard/index.blade.php ENDPATH**/ ?>
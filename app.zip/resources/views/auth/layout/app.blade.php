<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default"
    data-assets-path="../assets/" data-template="vertical-menu-template-free" data-style="light">
    @include('backend.layout.head')
<body>
    @yield('content')
    @include('backend.layout.scripts')
</body>
</html>
